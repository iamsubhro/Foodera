-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2018 at 05:21 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurantdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `creativefoods`
--

CREATE TABLE `creativefoods` (
  `food_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `details` varchar(400) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `quantity` varchar(30) DEFAULT NULL,
  `rating` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `creativefoods`
--

INSERT INTO `creativefoods` (`food_id`, `name`, `details`, `price`, `quantity`, `rating`) VALUES
(1, 'Manchurian', 'Deep-fried mixed vegetable balls sautéed with ginger-garlic paste, chilli sauce and chopped vegetables', 200, '1 Plate', 0),
(2, 'Real Lassi', 'Milky,Curdy,Natural', 50, '1 Cup', 0),
(3, 'Vegitarian Plate', 'North Indian dish', 100, '1 Plate', 0),
(4, 'Vegitarian Pizza', '10 Inches radius Italian ,Vegetarian , Pizza', 200, '1', 0),
(5, 'Parantha Dahi', 'Potato Parantha with sweet curd and icecream', 100, '1 Plate', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fooditems`
--

CREATE TABLE `fooditems` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `details` varchar(400) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fooditems`
--

INSERT INTO `fooditems` (`id`, `name`, `details`, `price`, `image`) VALUES
(1, 'Vegitarian Pizza', 'Italian ,Vegetarian , Pizza', 0, 'pizza.jpg'),
(3, 'Cream Stone', 'Cakes-Bakery, Icecream', 0, 'icecream.jpg'),
(4, 'Real Lassi', 'Milky,Curdy,Natural', 0, 'lassi.jpg'),
(5, 'Vegitarian Plate', 'North Indian dish', 0, 'deshi_khana.jpg'),
(6, 'Veg. Manchurian', 'Deep-fried mixed vegetable balls sautéed with ginger-garlic paste, chilli sauce and chopped vegetables', 0, 'manchurian.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `mob_no` bigint(12) NOT NULL,
  `name` varchar(50) NOT NULL,
  `food_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT '0',
  `date1` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `mob_no`, `name`, `food_id`, `type`, `rating`, `date1`) VALUES
(6, 9876543210, 'creativefoods', 1, 'liveorder', 4, '2018-03-26'),
(7, 9876543210, 'sipnbite', 2, 'liveorder', 0, '2018-03-26'),
(8, 9876543210, 'sipnbite', 2, 'liveorder', 0, '2018-03-26'),
(9, 9876543210, 'sipnbite', 2, 'liveorder', 0, '2018-03-26'),
(10, 9876543210, 'sipnbite', 2, 'liveorder', 0, '2018-03-26'),
(11, 9876543210, 'creativefoods', 1, 'liveorder', 4, '2018-03-26'),
(12, 9876543210, 'creativefoods', 1, 'preorder', 4, '2018-03-26'),
(13, 9876543210, 'creativefoods', 1, 'liveorder', 4, '2018-03-26'),
(14, 9876543210, 'sipnbite', 1, 'preorder', 0, '2018-03-27'),
(15, 9876543210, 'sipnbite', 2, 'preorder', 0, '2018-03-27'),
(16, 9876543210, 'sipnbite', 1, 'preorder', 0, '2018-03-27'),
(17, 9876543210, 'sipnbite', 2, 'preorder', 0, '2018-03-27'),
(18, 9876543210, 'sipnbite', 2, 'preorder', 0, '2018-03-27'),
(19, 9876543210, 'sipnbite', 2, 'preorder', 0, '2018-03-27'),
(20, 9876543210, 'sipnbite', 1, 'delivery', 0, '2018-03-27'),
(21, 9876543210, 'sipnbite', 2, 'delivery', 0, '2018-03-27'),
(22, 9876543210, 'creativefoods', 1, 'liveorder', 4, '2018-03-27'),
(23, 9876543210, 'creativefoods', 1, 'preorder', 4, '2018-03-27'),
(24, 9876543210, 'creativefoods', 1, 'preorder', 4, '2018-03-27'),
(25, 9876543210, 'creativefoods', 1, 'preorder', 4, '2018-03-27'),
(26, 9876543210, 'creativefoods', 2, 'preorder', 4, '2018-03-27'),
(27, 9876543210, 'creativefoods', 1, 'preorder', 0, '2018-03-27'),
(28, 9876543210, 'sipnbite', 1, 'preorder', 0, '2018-03-27'),
(29, 9876543210, 'sipnbite', 2, 'preorder', 0, '2018-03-27'),
(30, 9876543210, 'creativefoods', 4, 'preorder', 0, '2018-03-27'),
(31, 9876543210, 'creativefoods', 2, 'delivery', 0, '2018-03-27'),
(32, 9876543210, 'creativefoods', 4, 'liveorder', 0, '2018-03-27'),
(33, 9876543210, 'creativefoods', 4, 'liveorder', 0, '2018-03-27');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `id` int(11) NOT NULL,
  `mob_no` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `delivery` varchar(20) NOT NULL,
  `preorder` varchar(20) NOT NULL,
  `liveorder` varchar(20) NOT NULL,
  `premoney` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `street` varchar(300) NOT NULL,
  `district` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zipcode` int(12) NOT NULL,
  `country` varchar(40) NOT NULL,
  `working1` varchar(20) NOT NULL,
  `working2` varchar(20) NOT NULL,
  `working3` varchar(20) NOT NULL,
  `working4` varchar(20) NOT NULL,
  `working5` varchar(20) NOT NULL,
  `working6` varchar(20) NOT NULL,
  `working7` varchar(20) NOT NULL,
  `from1` varchar(20) NOT NULL,
  `from2` varchar(20) NOT NULL,
  `from3` varchar(20) NOT NULL,
  `from4` varchar(20) NOT NULL,
  `from5` varchar(20) NOT NULL,
  `from6` varchar(20) NOT NULL,
  `from7` varchar(20) NOT NULL,
  `to1` varchar(20) NOT NULL,
  `to2` varchar(20) NOT NULL,
  `to3` varchar(20) NOT NULL,
  `to4` varchar(20) NOT NULL,
  `to5` varchar(20) NOT NULL,
  `to6` varchar(20) NOT NULL,
  `to7` varchar(20) NOT NULL,
  `rating` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `mob_no`, `email`, `delivery`, `preorder`, `liveorder`, `premoney`, `name`, `image`, `street`, `district`, `city`, `state`, `zipcode`, `country`, `working1`, `working2`, `working3`, `working4`, `working5`, `working6`, `working7`, `from1`, `from2`, `from3`, `from4`, `from5`, `from6`, `from7`, `to1`, `to2`, `to3`, `to4`, `to5`, `to6`, `to7`, `rating`) VALUES
(33, '9876543210', 'anubhavsingh5132506@gmail.com', 'on', 'on', 'on', 40, 'creativefoods', 'creativefoods.jpg', 'Level-Block-9', 'Kharar', 'Chandigarh', 'Chandigarh', 140413, 'India', 'open', 'open', 'open', 'open', 'open', 'open', 'open', '9AM', '9AM', '9AM', '9AM', '9AM', '9AM', '9AM', '10PM', '10PM', '10PM', '10PM', '10PM', '10PM', '10PM', 0),
(34, '12345678', 'anubhavsingh5132506@gmail.com', 'on', 'on', '', 40, 'sipnbite', 'sipnbite.jpg', 'Level-block-7', 'morinda', 'Chandigarh', 'Chandigarh', 140413, 'India', 'open', 'open', 'open', 'open', 'open', 'open', 'open', '9AM', '9AM', '9AM', '9AM', '9AM', '9AM', '9AM', '10PM', '10PM', '10PM', '10PM', '10PM', '10PM', '10PM', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sipnbite`
--

CREATE TABLE `sipnbite` (
  `food_id` int(11) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `details` varchar(400) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `quantity` varchar(30) DEFAULT NULL,
  `rating` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sipnbite`
--

INSERT INTO `sipnbite` (`food_id`, `name`, `details`, `price`, `quantity`, `rating`) VALUES
(1, 'Manchurian', 'Deep-fried mixed vegetable balls sautéed with ginger-garlic paste, chilli sauce and chopped vegetables', 150, '1 Plate', 0),
(2, 'Maharaja Thali', 'Choice of matar paneer or paneer butter masala, dal makhani and dal tadka, seasonal vegetable, chhole, 6 poori, rice, raita, salad, pickle, papad and semiya kheer', 200, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `mob_no` bigint(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `mob_no`, `password`) VALUES
(2, 'anubhav', 12345678, '123456'),
(30, '1', 1, '1'),
(31, 'anubhav', 11, '11'),
(32, 'anubha', 1234, '12345'),
(33, 'anubhav', 123456789, '12345'),
(34, 'Anubhav Singh', 9876543210, '12345'),
(35, 'qwsedf', 0, 'wedrfgtyh'),
(36, '123', 0, 'erf'),
(37, 'anubhav', 123, '12345'),
(38, 'Anubhav Singh', 9876543211, '123456'),
(39, '2', 2, '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `creativefoods`
--
ALTER TABLE `creativefoods`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `fooditems`
--
ALTER TABLE `fooditems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sipnbite`
--
ALTER TABLE `sipnbite`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `creativefoods`
--
ALTER TABLE `creativefoods`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fooditems`
--
ALTER TABLE `fooditems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `sipnbite`
--
ALTER TABLE `sipnbite`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
